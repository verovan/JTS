#!/usr/bin/env python
#-*- coding: utf-8 -*-

from os import chdir, system


# Instalar dependencias
system('apt-get install gcc build-essential')

# Descargar Jailkit
system('wget http://olivier.sessink.nl/jailkit/jailkit-2.17.tar.gz')

# Compilar Jailkit
system('tar -xzvf jailkit-2.17.tar.gz')
chdir('jailkit-2.17')
system('./configure')
system('make')
system('make install')
chdir('../')

# Configuración JailKit
system('mv jk_init.ini /etc/jailkit/jk_init.ini')

# Habilitar comando addlab y newlab en el sistema
system('chmod +x newlab.py')
system('mv newlab.py /usr/bin/newlab')
system('rm -fr jailkit-2.17*')
